module.exports = async ({ deployments, getNamedAccounts }) => {
    const { deploy } = deployments;
    const { deployer } = await getNamedAccounts();

    console.log("Deploying ToDoList contract...");

    await deploy('ToDoList', {
        from: deployer,
        log: true,
    });

    console.log("ToDoList deployed successfully.");
};
module.exports.tags = ['ToDoList'];
